# Overview
1. This is an MVC application that consumes IEX Trading REST API and displays data on a web-page.
2. It also creates a database with two tables and saves data in those tables.

# Usage
1. Download and extract the zip.
2. Import project in Visual Studio.
3. Run, change and modify the project to your desire.

